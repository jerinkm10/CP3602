<footer>

  <div class="row">

    <div class="col-md-6">

      <p>Exacore Employee Portal P.1.2021.</p>

    </div>

    <div class="col-md-6">

      <p class="powered">Powered by Exacore Digital Team.2021</p>

    </div>

  </div>

</footer>



<script src="<?php echo e(url('/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10.15.5/dist/sweetalert2.min.js"></script>
<?php /**PATH E:\xamppes\htdocs\dynamic-forms\resources\views/pages/footer.blade.php ENDPATH**/ ?>