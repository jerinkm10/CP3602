<head>

    <meta charset="utf-8">

    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <meta name="description" content="">

    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">

    <meta name="generator" content="Jekyll v4.1.1">

    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>CP360</title>



    <!-- Bootstrap core CSS -->

	<link href="<?php echo e(url('/css/bootstrap.min.css')); ?>" rel="stylesheet">

    <link rel="stylesheet" href="<?php echo e(url('/css/font-awesome.min.css')); ?>">

	<link href="<?php echo e(url('/css/dashboard.css')); ?>" rel="stylesheet">  
	
	<link href="<?php echo e(url('/css/jquery.dataTables.min.css')); ?>" rel="stylesheet">
	
	<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- Include SweetAlert CSS and JS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@10.15.5/dist/sweetalert2.min.css">
    

	
	<!-- Custom styles for this template -->

    <link href="<?php echo e(url('/css/style.css')); ?>" rel="stylesheet">
	
	<!--
	
	
	
    <script src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js"></script>

	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.2/css/jquery.dataTables.min.css">	

    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/dataTables.bootstrap.min.css" />  
	
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.2/css/jquery.dataTables.min.css">

	-->
  </head>  <?php /**PATH E:\xamppes\htdocs\dynamic-forms\resources\views/pages/head.blade.php ENDPATH**/ ?>