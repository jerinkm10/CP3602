first run 
php aritsan serve 

php artisan migrate:fresh

 php artisan db:seed --class=UsersTableSeeder