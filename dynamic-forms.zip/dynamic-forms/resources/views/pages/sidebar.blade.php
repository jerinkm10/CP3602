<div class="container-fluid">

  <div class="row">

    <nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">

      <div class="sidebar-sticky">

        <ul class="nav flex-column">                 
         
          <li class="nav-item">

            <a class="nav-link" href="{{ url('/dasboard') }}">

              <i class="fa fa-plus"></i>

              Add Form

              <i class="fa fa-angle-right arow"></i>

            </a>

          </li>
        </ul>

      </div>

    </nav>



    