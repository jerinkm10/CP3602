<!DOCTYPE html>
<html>
<head>
    <title>Form Created</title>
</head>
<body>
    <h1>Form Created Successfully</h1>
    <p>A new form has been created with the following details:</p>
    <p>Form ID: {{ $form->id }}</p>
    <p>Form Name: {{ $form->name }}</p>
</body>
</html>
